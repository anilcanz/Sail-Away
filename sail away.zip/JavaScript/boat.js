
    // Select all clickable containers
    const containers = document.querySelectorAll('.radio-container');
    
    containers.forEach(container => {
        container.addEventListener('click', function() {
            // Get the data attribute value for the selected type
            const selectedType = this.getAttribute('data-type-id');
            
            // Set the hidden input value
            document.getElementById('selectedType').value = selectedType;

            // Submit the form
            this.closest('form').submit();
        });

        // Add hover effect to indicate clickability
        container.style.cursor = 'pointer';
        container.addEventListener('mouseover', function() {
            this.style.transform = 'scale(1.03)';
            this.style.boxShadow = '0 4px 8px rgba(0, 0, 0, 0.2)';
        });
        container.addEventListener('mouseout', function() {
            this.style.transform = 'scale(1)';
            this.style.boxShadow = '0 1px 3px rgba(0, 0, 0, 0.1)';
        });
    });

    // Select all clickable location containers
    const locationContainers = document.querySelectorAll('.location-container');

    locationContainers.forEach(container => {
        container.addEventListener('click', function() {
            // Get the data attribute value for the selected location
            const selectedLocation = this.getAttribute('data-location-id');
            
            // Set the hidden input value
            document.getElementById('selectedLocation').value = selectedLocation;

            // Submit the form
            this.closest('form').submit();
        });
    });

