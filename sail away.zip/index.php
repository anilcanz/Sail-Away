<?php

require('./includes/DBconnection.php');
require('./includes/functions.php');

$pdo = ConnectDB();

if(!empty($_GET['pageNr']))
    $pageNr = $_GET['pageNr'];
else 
    $pageNr = null;

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="stylesheets/menu.css">
</head>
<body>
    <header>

    </header>

    <div id="MenuWrapper">
        <nav>
            <?php
                require('./pages/menu.php');
            ?>
        </nav>        
    </div>

    <div id="MainWrapper">
        <div id="Banner"></div>
            <main>
                <?php

                    switch($pageNr)
                    {
                        case 1:	require('./pages/boats.php');
				break;
                        case 2:	require('./pages/reservations.php');
                                break;
                        case 3:	require('./pages/contact.php');
                                break;
                        case 4:	require('./pages/profile.php');
                                break;
                        case 5:	require('./pages/admin/customers.php');
                                break;
                        case 6:	require('./pages/admin/reservation_admin.php');
                                break;
                        case 7:	require('./pages/register.php');
                                break;
                        case 8: require('./pages/admin/boat_add.php');
                                break;
                        case 9: require('./pages/reservation_process.php');
                                break;
                        case 10: require('./pages/changePersInfo.php');
                                break;
                        case 11: require('./pages/manageReservation.php');
                                break;
                        case 98:require('./pages/login.php');
                                break;
                        case 99:require('./pages/logout.php');
                                break;
                        default:require('./pages/home.php');
                                break;
                    }
                
                ?>
    </div>


</body>
</html>
