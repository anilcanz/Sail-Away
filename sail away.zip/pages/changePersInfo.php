<?php

if (!LoginCheck($pdo)) {
    RedirectToPage(NULL, 98);
}

// Connect to the database
$pdo = ConnectDB();

// Fetch user information from the database
$sth = $pdo->prepare("SELECT username, phoneNumber, email FROM users WHERE customerID = :customerID");
$sth->execute([':customerID' => $_SESSION['customerID']]);
$user = $sth->fetch(PDO::FETCH_ASSOC);

// Change personal information
// Initialize fields
$PhoneNumber = $Email = $Username = $CurrentPassword = $Password = $ReTypePassword = null;

// Initialize error fields
$PhoneErr = $EmailErr = $UserErr = $CurrentPassErr = $PassErr = $ReTypePasswordErr = null;

if (isset($_POST['ChangeInfo'])) {
    $CheckOnErrors = false;

    // Retrieve input values
    $Username = $_POST['Username'] ?? $Username;
    $PhoneNumber = $_POST['PhoneNumber'] ?? $PhoneNumber;
    $Email = $_POST['Email'] ?? $Email;
    $CurrentPassword = $_POST['CurrentPassword'] ?? '';
    $Password = $_POST['Password'] ?? '';
    $ReTypePassword = $_POST['ReTypePassword'] ?? '';

    // Validation for Phone Number
    if (empty($PhoneNumber)) {
        $PhoneErr = "Phone number is required.";
        $CheckOnErrors = true;
    } elseif (!is_NL_Telnr($PhoneNumber)) {
        $PhoneErr = "Please enter a valid phone number.";
        $CheckOnErrors = true;
    }

    // Validation for Email
    if (empty($Email)) {
        $EmailErr = "Email address is required.";
        $CheckOnErrors = true;
    } elseif (!is_Email($Email)) {
        $EmailErr = "Please enter a valid email address.";
        $CheckOnErrors = true;
    }

    // Validation for Username
    if (empty($Username)) {
        $UserErr = "Username is required.";
        $CheckOnErrors = true;
    } else {
        // Check if username is unchanged
        $sth = $pdo->prepare("SELECT username FROM users WHERE customerID = :customerID");
        $sth->execute([':customerID' => $_SESSION['customerID']]);
        $currentUser = $sth->fetch(PDO::FETCH_ASSOC);

        if ($Username !== $currentUser['username']) {
            // Check if username is unique
            if (!is_Username_Unique($Username, $pdo)) {
                $UserErr = "This username is already taken, please choose another.";
                $CheckOnErrors = true;
            }
        }
    }

    // Validation for Password
    if (!empty($Password) || !empty($ReTypePassword)) {
        if (empty($CurrentPassword)) {
            $CurrentPassErr = "You must enter your current password to change it.";
            $CheckOnErrors = true;
        } else {
            // Verify current password
            $sth = $pdo->prepare("SELECT password, salt FROM users WHERE customerID = :customerID");
            $sth->execute([':customerID' => $_SESSION['customerID']]);
            $user = $sth->fetch(PDO::FETCH_ASSOC);

            if (!$user || hash('sha512', $CurrentPassword . $user['salt']) !== $user['password']) {
                $CurrentPassErr = "Incorrect current password.";
                $CheckOnErrors = true;
            }
        }

        // New Password Validation
        if (empty($Password)) {
            $PassErr = "New password is required.";
            $CheckOnErrors = true;
        } elseif (!is_minlength($Password, 6)) {
            $PassErr = "Password must be at least 6 characters long.";
            $CheckOnErrors = true;
        }

        if ($Password !== $ReTypePassword) {
            $ReTypePasswordErr = "Passwords do not match.";
            $CheckOnErrors = true;
        }
    }

    // If there are no errors, update the information
    if (!$CheckOnErrors) {
        $query = "UPDATE users SET phoneNumber = :PhoneNumber, email = :Email, username = :Username";
        $parameters = [
            ':PhoneNumber' => $PhoneNumber,
            ':Email' => $Email,
            ':Username' => $Username,
            ':customerID' => $_SESSION['customerID']
        ];

        // Update password if provided
        if (!empty($Password)) {
            $Salt = hash('sha512', uniqid(mt_rand(1, mt_getrandmax()), true));
            $PasswordHash = hash('sha512', $Password . $Salt);

            $query .= ", password = :Password, salt = :Salt";
            $parameters[':Password'] = $PasswordHash;
            $parameters[':Salt'] = $Salt;
        }

        $query .= " WHERE customerID = :customerID";
        $sth = $pdo->prepare($query);
        $sth->execute($parameters);

        echo "Your personal information has been updated!";
        RedirectToPage(2, 4);
        exit;
    } else {
        require('./forms/myProfileForm.php');
    }
} else {
    require('./forms/myProfileForm.php');
}
?>
