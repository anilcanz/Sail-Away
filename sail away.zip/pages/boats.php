<?php

// TO DO!!!
// After location, give a selection on time and then the boats that are availeble
// Column grid max of 3

// Initialize selected values from POST data
$selectedType = $_POST['boattype'] ?? null;
$selectedLocation = $_POST['location'] ?? null;

// Fetch boat types 
$sql = "SELECT * FROM boat_type";
$stmt = $pdo->prepare($sql);
$stmt->execute();
$types = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch locations if a boat type is selected
$locations = [];
if ($selectedType) {
    $locationSql = "SELECT * FROM location";
    $locationStmt = $pdo->prepare($locationSql);
    $locationStmt->execute();
    $locations = $locationStmt->fetchAll(PDO::FETCH_ASSOC);
}

// Fetch boats if both a boat type and location are selected
$boats = [];
if ($selectedType && $selectedLocation) {
    $boatSql = "SELECT * FROM boat WHERE boat_type_boattypeID = :typeId AND locationID = :locationId";
    $boatStmt = $pdo->prepare($boatSql);
    $boatStmt->execute([':typeId' => $selectedType, ':locationId' => $selectedLocation]);
    $boats = $boatStmt->fetchAll(PDO::FETCH_ASSOC);
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Boat Reservations</title>
    <link rel="stylesheet" href="stylesheets/boats.css">
</head>
<body>
    <!--Boat Javascript -->
    <script src="JavaScript/boat.js" defer></script>
    <!-- Select Boat Type -->
    <form method="POST" action="">
    <h3>Select Boat Type</h3>
        <div class="grid-container">
            <?php foreach ($types as $type): ?>
                <div class="radio-container" data-type-id="<?php echo $type['boattypeID']; ?>">
                    <!-- Display image for boat type -->
                    <?php
                    $base64Image = base64_encode($type['image']); // Convert BLOB to Base64
                    echo '<img src="data:image/jpeg;base64,' . $base64Image . '" alt="' . htmlspecialchars($type['type']) . '" class="type-image" style="width:20%; height:auto;">';
                    ?>
                    <span><?php echo htmlspecialchars($type['type']); ?></span>
                </div>
            <?php endforeach; ?>
        </div>
        <!-- Hidden input to store selected type -->
        <input type="hidden" name="boattype" id="selectedType">
    </form>

    <!-- Select Location -->
    <?php if ($selectedType && !$selectedLocation): ?>
    <form method="POST" action="">
        <input type="hidden" name="boattype" value="<?php echo htmlspecialchars($selectedType); ?>">
        <input type="hidden" name="location" id="selectedLocation">
        <h3>Select Location</h3>
        <div class="grid-container">
            <?php foreach ($locations as $location): ?>
                <div class="location-container" data-location-id="<?php echo $location['locationID']; ?>">
                    <span><?php echo htmlspecialchars($location['name']); ?></span>
                </div>
            <?php endforeach; ?>
        </div>
    </form>
    <?php endif; ?>


    <!-- Display Available Boats -->
    <?php if ($selectedType && $selectedLocation): ?>
        <h1>Available Boats</h1>
        <div class="grid-container">
            <?php if (!empty($boats)): ?>
                <?php foreach ($boats as $boat): ?>
                    <div class="grid-item">
                        <div class="boat-details">
                            <h2><?php echo htmlspecialchars($boat['name']); ?></h2>
                            <p><strong>Brand:</strong> <?php echo htmlspecialchars($boat['brand']); ?></p>
                            <p><strong>Capacity:</strong> <?php echo htmlspecialchars($boat['capacity']); ?> people</p>
                            <p><strong>Construction Year:</strong> <?php echo htmlspecialchars($boat['constructionYear']); ?></p>
                            <p><strong>Length:</strong> <?php echo htmlspecialchars($boat['length']); ?> meters</p>
                            <p><?php echo htmlspecialchars($boat['description']); ?></p>
                            <p><strong>Price per Hour:</strong> €<?php echo number_format($boat['cph'], 2, ',', '.'); ?></p>
                            <a href="index.php?pageNr=2&boatID=<?php echo $boat['boatID']; ?>" class="reserve-button">Reserve</a>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>No available boats found for the selected type and location.</p>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</body>
</html>
