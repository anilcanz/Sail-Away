<?php

function login($Username, $password, $pdo) 
{
    // Prepare and execute the query
    $parameters = array(':Username' => $Username);
    $sth = $pdo->prepare('SELECT customerID, username, password, salt, level, firstName, lastName, email FROM users WHERE username = :Username LIMIT 1');
    $sth->execute($parameters);

    // Check if username exists in Database
    if ($sth->rowCount() == 1) {
        $row = $sth->fetch();

        // Hash the input password with the salt from the database
        $hashed_password = hash('sha512', $password . $row['salt']);

        // Verify if hashed password matches stored password
        if ($row['password'] === $hashed_password) {
            $user_browser = $_SERVER['HTTP_USER_AGENT'];

            // Set session variables
            $_SESSION['customerID'] = $row['customerID'];
            $_SESSION['username'] = $Username;
            $_SESSION['level'] = $row['level'];
            $_SESSION['login_string'] = hash('sha512', $hashed_password . $user_browser);
            $_SESSION['user'] = [
                'customerID' => $row['customerID'],
                'username' => $row['username'],
                'firstName' => $row['firstName'],
                'lastName' => $row['lastName'],
                'email' => $row['email']
            ];

            // Login successful
            return true;
        } else {
            // Password incorrect
            return false;
        }
    } else {
        // Username not found
        return false;
    }
}


$Error = NULL;

if (isset($_POST['login'])) {
    $Username = $_POST['Username'];
    $Password = $_POST['Password'];

    if (login($Username, $Password, $pdo)) {
        echo "You are logged in";
        RedirectToPage(5);
    } else {
        $Error = "The username or password is incorrect.";
        require('./forms/loginForm.php');
    }
} else {
    require('./forms/loginForm.php');
}
?>