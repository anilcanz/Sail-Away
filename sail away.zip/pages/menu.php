
<?php

$Level = 0; //Default level is 0
$MenuLoginLogout = '<li><a href="index.php?pageNr=98">Login</a></li>'; // default menuknop inloggen

if (LoginCheck($pdo))
{
    $Level = $_SESSION['level'];

    // button login gets changed to logout
    $MenuLoginLogout = '<li><a href="index.php?pageNr=99">Logout</a></li>';
}

$parameters = array(':Level'=>$Level);
$sth = $pdo->prepare('SELECT * FROM pages WHERE level <= :Level');

$sth->execute($parameters);

//display menu on the screen
echo '<ul id ="menu">';
echo '<li><a href="index.php">Home</a></li>'; 

while($row = $sth->fetch())
{
    //menu items out of Database
    echo '	<li><a href="index.php?pageNr='.$row['pageNr'].'">'.$row['name'].'</a></li>';
}

echo $MenuLoginLogout;

echo '</ul>';


?>