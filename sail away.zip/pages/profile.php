<?php
// Check if user is logged in
if (!LoginCheck($pdo)) {
    RedirectToPage(NULL, 98);
}

$pdo = ConnectDB();

// Fetch user's information
$userQuery = $pdo->prepare("SELECT * FROM users WHERE customerID = :customerID");
$userQuery->execute([':customerID' => $_SESSION['customerID']]);
$user = $userQuery->fetch(PDO::FETCH_ASSOC);

// Fetch user's reservations
$reservationsQuery = $pdo->prepare(
    "SELECT r.*, b.name AS name 
    FROM reservation r 
    JOIN boat b ON r.boatID = b.boatID
    WHERE customerID = :customerID
    AND status = 'Active'
    ");
$reservationsQuery->execute([':customerID' => $_SESSION['customerID']]);
$reservations = $reservationsQuery->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile & Reservations</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        .section {
            margin-bottom: 40px;
        }
        .button {
            background-color: #0056b3;
            color: white;
            border: none;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            border-radius: 5px;
            cursor: pointer;
        }
        .button:hover {
            background-color: #003d80;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            text-align: left;
            padding: 8px;
        }
        th {
            background-color: #f4f4f9;
        }
    </style>
</head>
<body>
    <!-- Personal Information Section -->
    <div class="section">
        <h2>Your Personal Information</h2> <br>
        <p><strong>First Name:</strong> <?php echo htmlspecialchars($user['firstName']); ?></p> <br>
        <p><strong>Last Name:</strong> <?php echo htmlspecialchars($user['lastName']); ?></p> <br>
        <p><strong>Phone Number:</strong> <?php echo htmlspecialchars($user['phoneNumber']); ?></p> <br>
        <p><strong>Email:</strong> <?php echo htmlspecialchars($user['email']); ?></p>
        <br>
        <form action="index.php?pageNr=10" method="POST">
            <button type="submit" class="button">Change Information</button>
        </form>
    </div>

    <!-- Reservations Section -->
    <div class="section">
        <h2>Your Reservations</h2>
        <?php if (count($reservations) > 0): ?>
        <table>
            <tr>
                <th>Reservation Code</th>
                <th>Boat Name</th>
                <th>Start Date</th>
                <th>End Date</th>
                <th>Time Slot</th>
                <th>Actions</th>
            </tr>
            <?php foreach ($reservations as $reservation): ?>
            <tr>
                <td><?php echo htmlspecialchars($reservation['reservationID']); ?></td>
                <td><?php echo htmlspecialchars($reservation['name']);?></td>
                <td><?php echo htmlspecialchars($reservation['dateStart']); ?></td>
                <td><?php echo htmlspecialchars($reservation['dateEnd']); ?></td>
                <td><?php echo htmlspecialchars($reservation['timeSlot']); ?></td>
                <td>
                    <!-- Change reservation -->
                    <form action="./pages/manageReservation.php" method="GET" style="display:inline;">
                        <input type="hidden" name="reservationID" value="<?php echo $reservation['reservationID']; ?>">
                        <button type="submit" name="changeReservation" class="button">Change</button>
                    </form>
                    <!-- Delete reservation -->
                    <form action="" method="POST" style="display:inline;">
                        <input type="hidden" name="reservationID" value="<?php echo $reservation['reservationID']; ?>">
                        <button type="submit" name="deleteReservation" class="button" style="background-color: #b30000;">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; ?>
        </table>
        <?php else: ?>
        <br>
        <p>You have no reservations. Click <a href="index.php?pageNr=1">here</a> to make a reservation</p>
        
        <?php endif; ?>
    </div>
</body>
</html>

<?php
// Handle deletion of a reservation
if (isset($_POST['deleteReservation'])) {
    $reservationID = $_POST['reservationID'];
    try {
        // Update reservation status to "Cancelled"
        $query = $pdo->prepare("
            UPDATE reservation
            SET status = 'Canceled'
            WHERE reservationID = :reservationID 
            AND customerID = :customerID
        ");
        $query->execute([
            ':reservationID' => $reservationID,
            ':customerID' => $_SESSION['customerID']
        ]);
        // Redirect to the same page
        header("Location: index.php?pageNr=4");
        exit;
    } catch (PDOException $e) {
        die("Error updating reservation: " . $e->getMessage());
    }
}


// points of interest :
// - Delete action needs to be refreshed out of it self
// - Update (Change) button needs to be fully working
?>