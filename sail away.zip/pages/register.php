<?php

// Initialize fields
$FirstName = $Infex = $LastName = $BirthDate = $PhoneNumber = $Email = $Username = $Password = $ReTypePassword = NULL;

// Initialize error fields
$FnameErr = $InfexErr = $LnameErr = $BirthDateErr = $PhoneErr = $EmailErr = $UserErr = $PassErr = $ReTypePasswordErr = NULL;

if (isset($_POST['Register'])) {
    $CheckOnErrors = false;

    $FirstName = $_POST["FirstName"];
    $Infex = $_POST["Infex"];
    $LastName = $_POST["LastName"];
    $BirthDate = $_POST["BirthDate"];
    $PhoneNumber = $_POST["PhoneNumber"];
    $Email = $_POST["Email"];
    $Username = $_POST["Username"];
    $Password = $_POST["Password"];
    $ReTypePassword = $_POST["ReTypePassword"];

    // Validation for First Name
    if (empty($FirstName)) {
        $FnameErr = "This field is required";
        $CheckOnErrors = true;
    } elseif (!is_Char_Only($FirstName) || !is_minlength($FirstName, 2)) {
        $FnameErr = "Must be letters only and at least 2 characters long";
        $CheckOnErrors = true;
    }

    // Validation for Last Name
    if (empty($LastName)) {
        $LnameErr = "This field is required";
        $CheckOnErrors = true;
    } elseif (!is_Char_Only($LastName) || !is_minlength($LastName, 2)) {
        $LnameErr = "Must be letters only and at least 2 characters long";
        $CheckOnErrors = true;
    }

    // Validation for Phone Number
    if (empty($PhoneNumber)) {
        $PhoneErr = "This field is required";
        $CheckOnErrors = true;
    } elseif (!is_NL_Telnr($PhoneNumber)) {
        $PhoneErr = "Not a valid phone number";
        $CheckOnErrors = true;
    }

    // Validation for Email
    if (empty($Email)) {
        $EmailErr = "This field is required";
        $CheckOnErrors = true;
    } elseif (!is_Email($Email)) {
        $EmailErr = "Not a valid email address";
        $CheckOnErrors = true;
    }

    // Validation for Username
    if (empty($Username)) {
        $UserErr = "This field is required";
        $CheckOnErrors = true;
    } elseif (!is_Username_Unique($Username, $pdo)) {
        $UserErr = "This username is already taken, choose another";
        $CheckOnErrors = true;
    }

    // Validation for Password
    if (empty($Password)) {
        $PassErr = "This field is required";
        $CheckOnErrors = true;
    } elseif (!is_minlength($Password, 6)) {
        $PassErr = "Password must be at least 6 characters long";
        $CheckOnErrors = true;
    }

    // Validation for Retype Password
    if (empty($ReTypePassword)) {
        $ReTypePasswordErr = "This field is required";
        $CheckOnErrors = true;
    } elseif ($Password != $ReTypePassword) {
        $ReTypePasswordErr = "Passwords do not match";
        $CheckOnErrors = true;
    }

    if ($CheckOnErrors) {
        require('./forms/registerForm.php');
    } else {
        // Create unique salt and hash the password
        $Salt = hash('sha512', uniqid(mt_rand(1, mt_getrandmax()), true));
        $PasswordHash = hash('sha512', $Password . $Salt);

        // Prepare the parameters
        $parameters = array(
            ':FirstName' => $FirstName,
            ':Infex' => $Infex,
            ':LastName' => $LastName,
            ':BirthDate' => $BirthDate,
            ':PhoneNumber' => $PhoneNumber,
            ':Email' => $Email,
            ':Username' => $Username,
            ':Password' => $PasswordHash,
            ':Salt' => $Salt,
            ':Level' => 1
        );

        // Insert into the database
        $sth = $pdo->prepare("INSERT INTO users (firstName, infix, lastName, birthDate, phoneNumber, email, username, password, salt, level)
                              VALUES (:FirstName, :Infex, :LastName, :BirthDate, :PhoneNumber, :Email, :Username, :Password, :Salt, :Level)");

        $sth->execute($parameters);
        echo "You're succesfully registered!";
        RedirectToPage(2, 98);
        }
} else {
    require('./forms/registerForm.php');
}

?>
