<?php
if (LoginCheck($pdo)) {
    if ($_SESSION['level'] >= 1) {
        // Initialize fields
        $Name = $Brand = $Capacity = $ConstructionYear = $Length = $Description = $Cph = $NameType = $DescriptionType = $ImageType = $NameLocation = $AddressLocation = $DescriptionLocation = NULL;
        // Initialize error fields
        $NameErr = $BrandErr = $CapErr = $ConsYearErr = $LengthErr = $DescErr = $CphErr = $NameTypeErr = $DescTypeErr = $ImageTypeErr = $NameLocErr = $AddrLocErr = $DescLocErr = NULL;

        // Fetch boat types for the dropdown
        $boatTypes = [];
        try {
            $sth = $pdo->prepare('SELECT boattypeID, type FROM boat_type');
            $sth->execute();
            $boatTypes = $sth->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            die("Error fetching boat types: " . $e->getMessage());
        }

        // Fetch locations for the dropdown
        $locations = [];
        try {
            $sth = $pdo->prepare('SELECT locationID, name FROM location');
            $sth->execute();
            $locations = $sth->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            die("Error fetching locations: " . $e->getMessage());
        }

// voeg boot toe
        if (isset($_POST['AddBoat'])) {
            $CheckOnErrors = false;

            $Name = $_POST["Name"];
            $Brand = $_POST["Brand"];
            $BoatTypeID = $_POST["BoatType"];
            $Capacity = $_POST["Capacity"];
            $ConstructionYear = $_POST["ConstructionYear"];
            $Length = $_POST["Length"];
            $Description = $_POST["Description"];
            $Cph = $_POST["Cph"];
            $LocationID = $_POST["Location"];

            if ($CheckOnErrors) {
                require('./forms/addBoatsForm.php');
            } else {
                // Form is validated
                $parameters = array(
                    ':Name' => $Name,
                    ':Brand' => $Brand,
                    ':Capacity' => $Capacity,
                    ':ConstructionYear' => $ConstructionYear,
                    ':Length' => $Length,
                    ':Description' => $Description,
                    ':Cph' => $Cph,
                    ':BoatTypeID' => $BoatTypeID,
                    ':LocationID' => $LocationID
                );

                // Insert the new boat
                $sth = $pdo->prepare('INSERT INTO boat (name, brand, capacity, constructionYear, length, description, cph, boat_type_boattypeID, locationID) 
                                    VALUES (:Name, :Brand, :Capacity, :ConstructionYear, :Length, :Description, :Cph, :BoatTypeID, :LocationID)');
                $sth->execute($parameters);

                echo "The boat is added to the boat summary.";
                RedirectToPage(3, 8);
            }
        }

// voeg boottype toe
        if (isset($_POST['AddType'])) {
            $CheckOnErrors = false;
    
            $NameType = $_POST["NameType"];
            $DescriptionType = $_POST["DescriptionType"];
            $ImageType = $_POST["ImageType"];
    
            if ($CheckOnErrors) {
                require('./forms/addBoatsForm.php');
            } else {
                // Form is validated
                $parameters = array(
                    ':Name' => $NameType,
                    ':Image' => $ImageType,
                    ':Description' => $DescriptionType
                );
    
                // Insert the new boat
                $sth = $pdo->prepare('INSERT INTO boat_type (type, image, description) 
                                    VALUES (:Name, :Image, :Description)');
                $sth->execute($parameters);
    
                echo "The type is added to the system.";
                RedirectToPage(3, 8);
            } 
        }

// voeg locatie toe
        if (isset($_POST['AddLocation'])) {
            $CheckOnErrors = false;
    
            $NameLocation = $_POST["NameLocation"];
            $AddressLocation = $_POST["AddressLocation"];
            $DescriptionLocation = $_POST["DescriptionLocation"];
    
            if ($CheckOnErrors) {
                require('./forms/addBoatsForm.php');
            } else {
                // Form is validated
                $parameters = array(
                    ':Name' => $NameLocation,
                    ':Address' => $AddressLocation,
                    ':Description' => $DescriptionLocation
                );
    
                // Insert the new boat
                $sth = $pdo->prepare('INSERT INTO location (name, address, description) 
                                    VALUES (:Name, :Address, :Description)');
                $sth->execute($parameters);
    
                echo "The location is added to the system.";
                RedirectToPage(3, 8);
            } 
        }
    } else {
        echo "You don't have the authority for this page.";
        RedirectToPage(5);
    }
} else {
    RedirectToPage(NULL, 98);
}
require('./forms/addBoatsForm.php');
?>