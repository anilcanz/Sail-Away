<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="stylesheets/loginform.css">
    <title>add boat-location-type</title>
</head>
<body>
    <?php 
    $selectedContent = '';
    if(isset($_POST['content'])) {
        $selectedContent = $_POST['content'];
    }
    ?>
    <form method="post" action="">
        <button type="submit" name="content" value="ADD">ADD</button>
        <button type="submit" name="content" value="EDIT">EDIT</button>
        <button type="submit" name="content" value="DEL">DELETE</button>
    </form>

    <?php if ($selectedContent === "ADD"): ?>
        <div class="content-section">

<div class="gridBoatLocationType">
<div class="gridBoatLocationTypeItem">

        <h1 id="h1-position">Add a boat</h1>
    <form name="addBoatsForm" action="" method="POST">
        <label for="Name">Name boat:</label>
        <input type="text" id="Name" Name="Name" value="<?php echo $Name; ?>"><?php echo $NameErr?>
            <br />
        <label for="Brand">Brand:</label>
        <input type="text" id="Brand" Name="Brand" value="<?php echo $Brand; ?>"><?php echo $BrandErr; ?>
            <br />
        <label for="BoatType">Boat Type:</label>
        <select name="BoatType" id="BoatType">
        <?php foreach ($boatTypes as $boat): ?>
        <option value="<?= htmlspecialchars($boat['boattypeID']) ?>" 
            <?= isset($BoatTypeID) && $BoatTypeID == $boat['boattypeID'] ? 'selected' : '' ?>>
            <?= htmlspecialchars($boat['type']) ?>
        </option>
        <?php endforeach; ?>
        </select>
        <?php if (isset($BoatTypeErr)) echo $BoatTypeErr; ?>
            <br />
        <label for="Location">Location:</label>
        <select name="Location" id="Location">
        <?php foreach ($locations as $location): ?>
        <option value="<?= htmlspecialchars($location['locationID']) ?>" 
            <?= isset($LocationID) && $LocationID == $location['locationID'] ? 'selected' : '' ?>>
            <?= htmlspecialchars($location['name']) ?>
        </option>
        <?php endforeach; ?>
        </select>
        <?php if (isset($LocationErr)) echo $LocationErr; ?>
            <br />
        <label for="Capacity">Capacity:</label>
        <input type="text" id="Capacity" Name="Capacity" value="<?php echo $Capacity; ?>"/><?php echo $CapErr?>
            <br />
        <label for="ConstructionYear">Construction Year:</label>
        <input type="text" id="ConstructionYear" Name="ConstructionYear" value="<?php echo $ConstructionYear; ?>"/><?php echo $ConsYearErr?>
            <br />
        <label for="Length">Length:</label>
        <input type="text" id="Length" Name="Length" value="<?php echo $Length; ?>"/><?php echo $LengthErr?>
            <br />
        <label for="Description">Description:</label>
        <input type="text" id="Description" Name="Description" value="<?php echo $Description; ?>"/><?php echo $DescErr?>
            <br />
        <label for="Cph">Cost Per Hour:</label>
        <input type="text" id="Cph" Name="Cph" value="<?php echo $Cph; ?>"/><?php echo $CphErr?>
            <br />
        <input type="submit" name="AddBoat" value="Add Boat">
    </form>
</div>


<div class="gridBoatLocationTypeItem">
        <h1>Add boat type</h1>
    <form name="addBoatsForm" action="" method="POST">
        <label for="NameType">Name typeboat:</label>
        <input type="text" id="NameType" Name="NameType" value="<?php echo $NameType; ?>"/><?php echo $NameTypeErr?>
            <br />
        <label for="DescriptionType">Description:</label>
        <input type="text" id="DescriptionType" Name="DescriptionType" value="<?php echo $DescriptionType; ?>"/><?php echo $DescTypeErr?>
            <br />
        <label for="ImageType">Upload Image:</label>
        <input type="file" id="ImageType" Name="ImageType" value="<?php echo $ImageType; ?>"/><?php echo $ImageTypeErr?>
            <br />
        <input type="submit" name="AddType" value="Add Type">
    </form>
</div>


<div class="gridBoatLocationTypeItem">
    <h1>Add a location</h1>
    <form name="addBoatsForm" action="" method="POST">
        <label for="NameLocation">Name Location:</label>
        <input type="text" id="NameLocation" Name="NameLocation" value="<?php echo $NameLocation; ?>"/><?php echo $NameLocErr?>
            <br />
        <label for="AddressLocation">Address:</label>
        <input type="text" id="AddessLocation" Name="AddressLocation" value="<?php echo $AddressLocation; ?>"><?php echo $AddrLocErr; ?>
            <br />
        <label for="DescriptionLocation">Description:</label>
        <input type="text" id="DescriptionLocation" Name="DescriptionLocation" value="<?php echo $DescriptionLocation; ?>"/><?php echo $DescLocErr?>
            <br />
        <input type="submit" name="AddLocation" value="Add Location">
    </form>
</div>
</div>
</div>
    <?php elseif ($selectedContent === "EDIT"): ?>
        <div class="content-section">
            <h2>EDIT</h2>
            <p>This is the second section of content. It only appears when you click the "EDIT" button.</p>
        </div>
    <?php elseif ($selectedContent === "DEL"): ?>
        <div class="content-section">
            <h2>DELETE</h2>
            <p>This is the third section of content. It only appears when you click the "DELETE" button.</p>
        </div>
    <?php else: ?>
        <p>No content has been selected. Please click a button above to display its corresponding content.</p>
    <?php endif; ?>
</body>
</html>