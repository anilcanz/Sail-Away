<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="stylesheets/loginform.css">
    <title>Login form</title>
</head>
<body>
    <h1>Log in</h1>
	<?php echo '<br />'.$Error.'<br />';?>
	<form name="loginForm" action="" method="post">
		<label for="Username">Username:</label>
		<input type="text" id="Username" name="Username" />
		<br />
		<label for="Password">Password:</label>
		<input type="password" id="Password" name="Password" />
		<br />		
		<input type="submit" name="login" value="Log in!" />
	</form>
	<br />
	Not a account yet? Register <a href="index.php?pageNr=7">here</a>

</body>
</html>