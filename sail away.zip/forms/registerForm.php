<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="stylesheets/registerform.css">
    <title>Register form</title>
</head>
<body>
    
    <h1>Registration</h1>

    <div class="container">

        <form name="RegisterForm" action="" method="post">
            <label for="FirstName">First Name:</label>
            <input type="text" id="FirstName" name="FirstName" value="<?php echo $FirstName; ?>"/><?php echo $FnameErr; ?>
            <br />
            <label for="Infex">Infex:</label>
            <input type="text" id="Infex" name="Infex" value="<?php echo $Infex; ?>"/><?php echo $InfexErr; ?>
            <br />
            <label for="LastName">Last Name:</label>
            <input type="text" id="LastName" name="LastName" value="<?php echo $LastName; ?>"/><?php echo $LnameErr; ?>
            <br />
            <label for="BirthDate">Birth Date:</label>
            <input type="text" id="BirthDate" name="BirthDate" value="<?php echo $BirthDate; ?>"/><?php echo $BirthDateErr; ?>
            <br />
            <label for="PhoneNumber">Phone Number:</label>
            <input type="text" id="PhoneNumber" name="PhoneNumber" value="<?php echo $PhoneNumber; ?>"/><?php echo $PhoneErr; ?>
            <br />
            <label for="Email">Email:</label>
            <input type="text" id="Email" name="Email" value="<?php echo $Email; ?>"/><?php echo $EmailErr; ?>
            <br />
            <br />
            <label for="Username">Username:</label>
            <input type="text" id="Username" name="Username" value="<?php echo $Username; ?>"/><?php echo $UserErr; ?>
            <br />
            <label for="Password">Password:</label>
            <input type="password" id="Password" name="Password"/><?php echo $PassErr; ?>
            <br />		
            <label for="ReTypePassword">Repeat Password:</label>
            <input type="password" id="ReTypePassword" name="ReTypePassword"/><?php echo $ReTypePasswordErr; ?>
            <br />		
            <input type="submit" name="Register" value="Register!">
        </form>
    </div>
</body>
</html>