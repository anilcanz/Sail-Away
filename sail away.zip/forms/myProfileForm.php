<?php

if(!LoginCheck($pdo)) {
    RedirectToPage(NULL, 98);
}

$pdo = ConnectDB();

// Fetch user's information
$userQuery = $pdo->prepare("SELECT * FROM users WHERE customerID = :customerID");
$userQuery->execute([':customerID' => $_SESSION['customerID']]);
$user = $userQuery->fetch(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="stylesheets/registerform.css">
    <title>Document</title>
</head>
<body>
    <h1>Change Personal Information</h1>
    <br>
    <form action="" method="POST">
        <label for="Username">Username:</label>
        <input type="text" id="Username" name="Username" value="<?php echo htmlspecialchars($user['username']); ?>"/>
        <?php echo $UserErr; ?>
        <br>

        <label for="PhoneNumber">Phone Number:</label>
        <input type="text" id="PhoneNumber" name="PhoneNumber" value="<?php echo htmlspecialchars($user['phoneNumber']); ?>"/>
        <?php echo $PhoneErr; ?>
        <br>

        <label for="Email">Email:</label>
        <input type="text" id="Email" name="Email" value="<?php echo htmlspecialchars($user['email']); ?>"/>
        <?php echo $EmailErr; ?>
        <br>

        <br>
        <h3><strong>Change Password</strong></h3>
        <br>

        <label for="CurrentPassword">Current Password:</label>
        <input type="password" id="CurrentPassword" name="CurrentPassword" value="" autocomplete="new-password"/>
        <?php echo $CurrentPassErr; ?>
        <br>

        <label for="Password">New Password:</label>
        <input type="password" id="Password" name="Password" value="" />
        <?php echo $PassErr; ?>
        <br>

        <label for="ReTypePassword">Re-Type Password:</label>
        <input type="password" id="ReTypePassword" name="ReTypePassword" value="" />
        <?php echo $ReTypePasswordErr; ?>
        <br>

        <input type="submit" name="ChangeInfo" value="Change Personal Information!">
    </form>

</body>
</html>