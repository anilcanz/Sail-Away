<?php

session_start();
// Function page

// Function Database connection
function ConnectDB()
{
    try {
        $pdo = new PDO("mysql:host=localhost;dbname=sail_away", "root", "");
        return $pdo;
    } catch (PDOException $e) {
        echo $e->getMessage();
    }
}

// Function redirecting to pages
function RedirectToPage($Seconds = NULL, $pageNr = NULL)
{
    if (!empty($Seconds)) {
        $Refresh = 'Refresh: ' . $Seconds . ';URL=';
    } else {
        $Refresh = 'Location: ';
    }

    if (!isset($pageNr)) {
        header($Refresh . "index.php");
        echo "<br />U wordt binnen " . $Seconds . " seconden doorgestuurd naar de hoofdpagina";
    } else {
        header($Refresh . "index.php?pageNr=" . $pageNr);
    }
} 

// Login check function
function LoginCheck($pdo)
{
    if (isset($_SESSION['customerID'], $_SESSION['username'], $_SESSION['login_string'])) {
        $CustomerID = $_SESSION['customerID'];
        $Login_String = $_SESSION['login_string'];
        $Username = $_SESSION['username'];

        $user_browser = $_SERVER['HTTP_USER_AGENT'];

        $parameters = array(':CustomerID' => $CustomerID);
        $sth = $pdo->prepare('SELECT password FROM users WHERE customerID = :CustomerID LIMIT 1');
        $sth->execute($parameters);

        if ($sth->rowCount() == 1) {
            $row = $sth->fetch();

            // Check if the login string matches
            $Login_Check = hash('sha512', $row['password'] . $user_browser);

            if ($Login_Check == $Login_String) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    } else {
        return false;
    }
}



/* Form validation functions */

/** Checks if an email address is valid
  * @return  boolean
  */
function is_email($Invoer)
{
   return (bool)(preg_match("/^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/", $Invoer));
}

/** Checks if a string meets the minimum length
  * @return  boolean
  */
function is_minlength($Invoer, $MinLengte)
{
    return (strlen($Invoer) >= (int)$MinLengte);
}

/** Checks if input is a valid Dutch postal code
  * @return  boolean
  */
function is_NL_PostalCode($Invoer)
{
    return (bool)(preg_match('#^[1-9][0-9]{3}\h*[A-Z]{2}$#i', $Invoer));
}

/** Checks if input is a valid Dutch phone number
  * @return  boolean
  */
function is_NL_Telnr($Invoer)
{
    return (bool)(preg_match('#^0[1-9][0-9]{0,2}-?[1-9][0-9]{5,7}$#', $Invoer) 
               && (strlen(str_replace(array('-', ' '), '', $Invoer)) == 10));
}

/** Checks if input only contains letters
  * @return  boolean
  */
function is_Char_Only($Invoer)
{
    return (bool)(preg_match("/^[a-zA-Z ]*$/", $Invoer));
}

// Check if username is unique in the database
function is_Username_Unique($Invoer, $pdo)
{
    $parameters = array(':Username' => $Invoer);
    $sth = $pdo->prepare('SELECT customerID FROM users WHERE username = :Username LIMIT 1');
    $sth->execute($parameters);

    // Check if the username exists in the DB
    return $sth->rowCount() == 0; // Returns true if username does not exist
}


?>
