<?php

define("HOST", "localhost");
define("DBNAME", "sail_away");
define("USERNAME", "root");
define("PASSWORD", "");


?>
